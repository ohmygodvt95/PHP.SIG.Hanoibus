		<footer id="links">
			<div class="container">
				<div class="col-sm-8" style="color:white">
					<h1>SIG - Semantic Innovation Group</h1>

					<h4>Mọi nội dung đều thuộc Semantic Innovation Group</h4>
					<h3><i class="fa fa-fw fa-mobile fa-2x"></i> <i class="fa fa-fw fa-laptop fa-2x"></i> <i class="fa fa-fw fa-tablet  fa-2x"></i></h3>
				</div>
				<div class="col-sm-4 text-center">
					<h1>Liên Kết</h1>
					<ul>
						<li><a href="">ISTeam</a></li>
						<li><a href="">Google</a></li>
						<li><a href="">A10k44</a></li>
					</ul>
				</div>
			</div>
		</footer>
